#pragma once

#include <string>
#include <vector>
#include <memory>
#include <sstream>

// 基础类型
class Type {
public:
    virtual ~Type() = default;
    virtual std::string toString() const = 0;
    virtual bool isInteger() const { return false; }
    virtual bool isPointer() const { return false; }
    virtual bool isArray() const { return false; }
    virtual bool isFunction() const { return false; }
};

class IntegerType : public Type {
public:
    int width;
    
    IntegerType(int w = 32) : width(w) {}
    
    std::string toString() const override {
        return "i" + std::to_string(width);
    }
    
    bool isInteger() const override { return true; }
};

class PointerType : public Type {
public:
    std::shared_ptr<Type> pointee;
    
    PointerType(std::shared_ptr<Type> p) : pointee(p) {}
    
    std::string toString() const override {
        return pointee->toString() + "*";
    }
    
    bool isPointer() const override { return true; }
};

class ArrayType : public Type {
public:
    std::shared_ptr<Type> elementType;
    std::vector<int> dimensions;  // 多维数组各维大小
    
    ArrayType(std::shared_ptr<Type> elem, const std::vector<int>& dims)
        : elementType(elem), dimensions(dims) {}
    
    std::string toString() const override {
        std::string result;
        for (int dim : dimensions) {
            result += "[" + std::to_string(dim) + " x ";
        }
        result += elementType->toString();
        for (size_t i = 0; i < dimensions.size(); ++i) {
            result += "]";
        }
        return result;
    }
    
    bool isArray() const override { return true; }
};

class FunctionType : public Type {
public:
    std::shared_ptr<Type> returnType;
    std::vector<std::shared_ptr<Type>> paramTypes;
    
    FunctionType(std::shared_ptr<Type> ret, const std::vector<std::shared_ptr<Type>>& params)
        : returnType(ret), paramTypes(params) {}
    
    std::string toString() const override {
        std::string result = returnType->toString() + " (";
        for (size_t i = 0; i < paramTypes.size(); ++i) {
            if (i > 0) result += ", ";
            result += paramTypes[i]->toString();
        }
        result += ")";
        return result;
    }
    
    bool isFunction() const override { return true; }
};

// 常用类型单例
inline std::shared_ptr<Type> i32Type() {
    static auto type = std::make_shared<IntegerType>(32);
    return type;
}

inline std::shared_ptr<Type> i1Type() {
    static auto type = std::make_shared<IntegerType>(1);
    return type;
}

inline std::shared_ptr<Type> voidType() {
    // void 用空指针表示
    return nullptr;
}