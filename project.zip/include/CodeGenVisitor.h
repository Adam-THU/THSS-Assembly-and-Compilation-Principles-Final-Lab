#pragma once

#include <string>
#include <map>
#include <memory>
#include <vector>
#include <sstream>
#include <any>
#include "antlr4-runtime.h"
#include "SysYParser.h"
#include "SysYParserBaseVisitor.h"
#include "IRBuilder.h"
#include "SymbolTable.h"
#include "Type.h"

// IR 值包装
struct IRValue {
    std::string name;  // 变量名或临时变量
    std::shared_ptr<Type> type;
    bool isConst = false;
    int constValue = 0;
    
    IRValue() = default;
    IRValue(const std::string& n, std::shared_ptr<Type> t)
        : name(n), type(t) {}
};

class CodeGenVisitor : public SysYParserBaseVisitor {
private:
    IRBuilder irBuilder;
    SymbolTable symTable;
    std::shared_ptr<Function> currentFunc;
    std::shared_ptr<BasicBlock> currentBB;
    int tmpVarCounter = 0;
    int blockCounter = 0;
    
    // 循环上下文（用于 break/continue）
    struct LoopContext {
        std::string exitLabel;    // break 跳转到这里
        std::string continueLabel; // continue 跳转到这里
    };
    std::vector<LoopContext> loopStack;
    
    // 临时变量生成
    std::string genTmpVar() {
        return "tmp" + std::to_string(tmpVarCounter++);
    }
    
    std::string genBlockName() {
        return "bb" + std::to_string(blockCounter++);
    }
    
    // 确保值是 i32
    IRValue ensureInt32(const IRValue& val) {
        if (auto intType = std::dynamic_pointer_cast<IntegerType>(val.type)) {
            if (intType->width == 32) {
                return val;
            } else if (intType->width == 1) {
                // 将 i1 转换为 i32
                std::string tmp = genTmpVar();
                currentBB->addInstruction("%"+tmp+" = zext i1 %"+val.name+" to i32");
                return IRValue(tmp, i32Type());
            }
        }
        return val;
    }
    
    // 安全的 any_cast 包装
    IRValue getIRValue(const std::any& val) {
        try {
            return std::any_cast<IRValue>(val);
        } catch (...) {
            return IRValue("0", i32Type());
        }
    }
    
public:
    CodeGenVisitor() {
        // 添加标准库函数声明
        irBuilder.addGlobalDeclaration("declare i32 @getint()");
        irBuilder.addGlobalDeclaration("declare void @putint(i32)");
        irBuilder.addGlobalDeclaration("declare void @putch(i32)");
    }
    
    std::string getIR() {
        return irBuilder.toString();
    }
    
    // 访问编译单元
    virtual std::any visitCompUnit(SysYParser::CompUnitContext *ctx) override {
        // 先访问所有声明（可能有全局变量）
        for (auto decl : ctx->decl()) {
            visit(decl);
        }
        
        // 再访问所有函数定义
        for (auto funcDef : ctx->funcDef()) {
            visit(funcDef);
        }
        
        return nullptr;
    }
    
    // 访问变量声明
    virtual std::any visitVarDecl(SysYParser::VarDeclContext *ctx) override {
        bool isGlobal = (currentFunc == nullptr);
        
        for (auto varDef : ctx->varDef()) {
            std::string varName = varDef->IDENT()->getText();
            std::vector<int> dims;
            
            // 获取数组维度
            for (size_t i = 0; i < varDef->constExp().size(); ++i) {
                auto constExp = varDef->constExp(i);
                if (constExp) {
                    int dimSize = evalConstExp(constExp);
                    dims.push_back(dimSize);
                }
            }
            
            std::shared_ptr<Type> varType = i32Type();
            if (!dims.empty()) {
                varType = std::make_shared<ArrayType>(i32Type(), dims);
            }
            
            if (isGlobal) {
                // 全局变量
                std::string llvmName = "@" + varName;
                if (dims.empty()) {
                    // 标量
                    int initVal = 0;
                    if (varDef->initVal()) {
                        initVal = evalConstInitVal(varDef->initVal());
                    }
                    irBuilder.addGlobalDeclaration("@" + varName + " = global i32 " + std::to_string(initVal) + ", align 4");
                } else {
                    // 数组（用 zeroinitializer）
                    irBuilder.addGlobalDeclaration("@" + varName + " = global " + varType->toString() + " zeroinitializer, align 4");
                }
                symTable.addSymbol(varName, varType, llvmName);
            } else {
                // 局部变量
                std::string llvmName = varName;
                std::string allocaInstr = "%" + varName + " = alloca ";
                if (dims.empty()) {
                    allocaInstr += "i32, align 4";
                } else {
                    allocaInstr += varType->toString() + ", align 4";
                }
                currentBB->addInstruction(allocaInstr);
                symTable.addSymbol(varName, varType, llvmName);
                
                // 处理初始化（仅标量）
                if (dims.empty() && varDef->initVal()) {
                    int initVal = evalConstInitVal(varDef->initVal());
                    currentBB->addInstruction("store i32 " + std::to_string(initVal) + ", i32* %" + varName + ", align 4");
                }
            }
        }
        
        return nullptr;
    }
    
    // 访问常量声明
    virtual std::any visitConstDecl(SysYParser::ConstDeclContext *ctx) override {
        for (auto constDef : ctx->constDef()) {
            std::string constName = constDef->IDENT()->getText();
            std::vector<int> dims;
            
            for (size_t i = 0; i < constDef->constExp().size(); ++i) {
                auto constExp = constDef->constExp(i);
                if (constExp) {
                    int dimSize = evalConstExp(constExp);
                    dims.push_back(dimSize);
                }
            }
            
            std::shared_ptr<Type> constType = i32Type();
            if (!dims.empty()) {
                constType = std::make_shared<ArrayType>(i32Type(), dims);
            }
            
            bool isGlobal = (currentFunc == nullptr);
            if (isGlobal) {
                // 全局常量
                if (dims.empty() && constDef->constInitVal() && constDef->constInitVal()->constExp()) {
                    int value = evalConstExp(constDef->constInitVal()->constExp());
                    irBuilder.addGlobalDeclaration("@" + constName + " = global i32 " + std::to_string(value) + ", align 4");
                } else {
                    irBuilder.addGlobalDeclaration("@" + constName + " = global " + constType->toString() + " zeroinitializer, align 4");
                }
                int value = 0;
                if (dims.empty() && constDef->constInitVal() && constDef->constInitVal()->constExp()) {
                    value = evalConstExp(constDef->constInitVal()->constExp());
                }
                symTable.addSymbol(constName, constType, "@" + constName, true, value);
            } else {
                // 局部常量
                int value = 0;
                if (dims.empty() && constDef->constInitVal() && constDef->constInitVal()->constExp()) {
                    value = evalConstExp(constDef->constInitVal()->constExp());
                }
                symTable.addSymbol(constName, constType, "", true, value);
            }
        }
        
        return nullptr;
    }
    
    // 访问函数定义
    virtual std::any visitFuncDef(SysYParser::FuncDefContext *ctx) override {
        std::string funcName = ctx->IDENT()->getText();
        
        // 返回类型
        std::shared_ptr<Type> returnType = nullptr;
        if (ctx->funcType()->INT()) {
            returnType = i32Type();
        }
        
        // 参数类型
        std::vector<std::shared_ptr<Type>> paramTypes;
        std::vector<std::string> paramNames;
        if (ctx->funcFParams()) {
            for (auto param : ctx->funcFParams()->funcFParam()) {
                paramNames.push_back(param->IDENT()->getText());
                int lbrackCount = param->LBRACK().size();
                if (lbrackCount == 0) {
                    paramTypes.push_back(i32Type());
                } else if (lbrackCount == 1) {
                    paramTypes.push_back(std::make_shared<PointerType>(i32Type()));
                } else {
                    std::vector<int> dims;
                    for (size_t i = 1; i < param->exp().size(); ++i) {
                        int dimSize = evalConstExp(param->exp(i)->addExp());
                        dims.push_back(dimSize);
                    }
                    auto arrayType = std::make_shared<ArrayType>(i32Type(), dims);
                    paramTypes.push_back(std::make_shared<PointerType>(arrayType));
                }
            }
        }
        
        // 创建函数
        currentFunc = irBuilder.createFunction(funcName, returnType);
        symTable.enterScope();
        
        // 创建入口块
        currentBB = currentFunc->createBlock(funcName + "Entry");
        
        // 添加参数并为每个参数创建本地副本
        for (size_t i = 0; i < paramNames.size(); ++i) {
            auto paramName = paramNames[i];
            auto paramType = paramTypes[i];
            currentFunc->params.push_back({paramType, paramName});
            
            // 为参数创建本地存储
            currentBB->addInstruction("%" + paramName + "_arg = alloca " + paramType->toString() + ", align 4");
            currentBB->addInstruction("store " + paramType->toString() + " %" + paramName + ", " + 
                                    paramType->toString() + "* %" + paramName + "_arg, align 4");
            
            // 在符号表中存储参数的本地副本地址
            symTable.addSymbol(paramName, paramType, paramName + "_arg");
            // 标记为参数（虽然现在访问的是副本）
            if (auto s = symTable.lookupLocal(paramName)) {
                s->isParam = false;  // 不再是直接参数，而是本地副本
            }
        }
        
        // 访问函数体
        visit(ctx->block());
        
        // 如果块没有终止符，添加返回语句
        if (!currentBB->hasTerminator) {
            if (returnType == nullptr) {
                currentBB->addInstruction("ret void");
            } else {
                currentBB->addInstruction("ret i32 0");
            }
            currentBB->setTerminator();
        }
        
        symTable.exitScope();
        currentFunc = nullptr;
        return nullptr;
    }
    
    // 访问块
    virtual std::any visitBlock(SysYParser::BlockContext *ctx) override {
        if (!currentFunc) return nullptr;
        
        symTable.enterScope();
        for (auto item : ctx->blockItem()) {
            visit(item);
        }
        symTable.exitScope();
        
        return nullptr;
    }
    
    // 访问语句
    virtual std::any visitStmt(SysYParser::StmtContext *ctx) override {
        if (!currentFunc || !currentBB || currentBB->hasTerminator) return nullptr;
        
        if (ctx->lVal() && ctx->ASSIGN()) {
            // 赋值语句
            IRValue lval = getLValAddress(ctx->lVal());
            IRValue rval = getIRValue(visit(ctx->exp()));
            rval = ensureInt32(rval);
            
            if (rval.isConst) {
                currentBB->addInstruction("store i32 " + std::to_string(rval.constValue) + ", i32* " + lval.name + ", align 4");
            } else {
                currentBB->addInstruction("store i32 %" + rval.name + ", i32* " + lval.name + ", align 4");
            }
        } else if (ctx->block()) {
            // 块语句
            visit(ctx->block());
        } else if (ctx->IF()) {
            // if 语句
            visitIfStmt(ctx);
        } else if (ctx->WHILE()) {
            // while 语句
            visitWhileStmt(ctx);
        } else if (ctx->BREAK()) {
            // break 语句
            if (!loopStack.empty()) {
                currentBB->addInstruction("br label %" + loopStack.back().exitLabel);
                currentBB->setTerminator();
            }
        } else if (ctx->CONTINUE()) {
            // continue 语句
            if (!loopStack.empty()) {
                currentBB->addInstruction("br label %" + loopStack.back().continueLabel);
                currentBB->setTerminator();
            }
        } else if (ctx->RETURN()) {
            // return 语句
            if (ctx->exp()) {
                IRValue retVal = getIRValue(visit(ctx->exp()));
                retVal = ensureInt32(retVal);
                if (retVal.isConst) {
                    currentBB->addInstruction("ret i32 " + std::to_string(retVal.constValue));
                } else {
                    currentBB->addInstruction("ret i32 %" + retVal.name);
                }
            } else {
                currentBB->addInstruction("ret void");
            }
            currentBB->setTerminator();
        } else if (ctx->exp()) {
            // 表达式语句
            visit(ctx->exp());
        }
        
        return nullptr;
    }
    
    // if 语句辅助
    void visitIfStmt(SysYParser::StmtContext *ctx) {
        std::string trueLabel = genBlockName();
        std::string falseLabel = genBlockName();
        std::string mergeLabel = genBlockName();
        
        // 条件在 LPAREN ... RPAREN 之间，是一个 lorExp
        // 需要从 ctx 的子树中提取条件
        auto condCtx = ctx->cond();
        IRValue cond = getIRValue(visit(condCtx));
        
        // 确保条件是 i1（如果是其他类型需要转换）
        if (cond.type) {
            if (auto intType = std::dynamic_pointer_cast<IntegerType>(cond.type)) {
                if (intType->width == 32) {
                    // i32 需要转换为 i1
                    if (!cond.isConst) {
                        std::string tmp = genTmpVar();
                        currentBB->addInstruction("%"+tmp+" = trunc i32 %"+cond.name+" to i1");
                        cond = IRValue(tmp, i1Type());
                    } else {
                        cond.type = i1Type();
                    }
                }
            }
        }
        
        // 条件分支 - 如果结果是 const，可以直接分支
        if (cond.isConst) {
            if (cond.constValue != 0) {
                // 条件为真，只执行 then 分支
                visit(ctx->stmt(0));
                if (!currentBB->hasTerminator) {
                    currentBB->addInstruction("br label %" + mergeLabel);
                    currentBB->setTerminator();
                }
            } else {
                // 条件为假，执行 else 分支（如果存在）
                if (ctx->ELSE()) {
                    visit(ctx->stmt(1));
                }
                if (!currentBB->hasTerminator) {
                    currentBB->addInstruction("br label %" + mergeLabel);
                    currentBB->setTerminator();
                }
            }
        } else {
            // 运行时条件分支
            currentBB->addInstruction("br i1 %" + cond.name + ", label %" + trueLabel + ", label %" + falseLabel);
            currentBB->setTerminator();
            
            // true 分支
            currentBB = currentFunc->createBlock(trueLabel);
            visit(ctx->stmt(0));
            if (!currentBB->hasTerminator) {
                currentBB->addInstruction("br label %" + mergeLabel);
                currentBB->setTerminator();
            }
            
            // false 分支
            currentBB = currentFunc->createBlock(falseLabel);
            if (ctx->ELSE()) {
                visit(ctx->stmt(1));
            }
            if (!currentBB->hasTerminator) {
                currentBB->addInstruction("br label %" + mergeLabel);
                currentBB->setTerminator();
            }
        }
        
        // merge 块
        currentBB = currentFunc->createBlock(mergeLabel);
    }
    
    // while 语句辅助
    void visitWhileStmt(SysYParser::StmtContext *ctx) {
        std::string condLabel = genBlockName();
        std::string bodyLabel = genBlockName();
        std::string exitLabel = genBlockName();
        
        // 跳到条件块
        currentBB->addInstruction("br label %" + condLabel);
        currentBB->setTerminator();
        
        // 条件块
        currentBB = currentFunc->createBlock(condLabel);
        auto condCtx = ctx->cond();
        IRValue cond = getIRValue(visit(condCtx));
        
        // 确保条件是 i1（如果是其他类型需要转换）
        if (cond.type) {
            if (auto intType = std::dynamic_pointer_cast<IntegerType>(cond.type)) {
                if (intType->width == 32) {
                    // i32 需要转换为 i1
                    if (!cond.isConst) {
                        std::string tmp = genTmpVar();
                        currentBB->addInstruction("%"+tmp+" = trunc i32 %"+cond.name+" to i1");
                        cond = IRValue(tmp, i1Type());
                    } else {
                        cond.type = i1Type();
                    }
                }
            }
        }
        
        if (cond.isConst) {
            if (cond.constValue != 0) {
                // 无限循环
                currentBB->addInstruction("br label %" + bodyLabel);
            } else {
                // 条件永远不成立，直接跳到退出
                currentBB->addInstruction("br label %" + exitLabel);
            }
        } else {
            currentBB->addInstruction("br i1 %" + cond.name + ", label %" + bodyLabel + ", label %" + exitLabel);
        }
        currentBB->setTerminator();
        
        // 循环体
        currentBB = currentFunc->createBlock(bodyLabel);
        
        // 推入循环上下文（用于 break/continue）
        loopStack.push_back({exitLabel, condLabel});
        
        visit(ctx->stmt(0));
        
        // 弹出循环上下文
        loopStack.pop_back();
        
        if (!currentBB->hasTerminator) {
            currentBB->addInstruction("br label %" + condLabel);
            currentBB->setTerminator();
        }
        
        // 退出块
        currentBB = currentFunc->createBlock(exitLabel);
    }
    
    // 访问表达式
    virtual std::any visitExp(SysYParser::ExpContext *ctx) override {
        return visit(ctx->addExp());
    }
    
    // 访问条件
    virtual std::any visitCond(SysYParser::CondContext *ctx) override {
        return visit(ctx->lorExp());
    }
    
    // 获取左值地址
    IRValue getLValAddress(SysYParser::LValContext *ctx) {
        std::string name = ctx->IDENT()->getText();
        Symbol *sym = symTable.lookup(name);
        if (!sym) {
            // 未定义的变量，假设是全局
            return IRValue("@" + name, i32Type());
        }
        // 使用符号表中存储的 llvmName
        // llvmName 可能是 @name（全局）或 name（本地）
        std::string addr = sym->llvmName;
        if (addr[0] != '@' && addr[0] != '%') {
            // 本地变量名称，需要加 % 前缀
            addr = "%" + addr;
        }
        return IRValue(addr, sym->type);
    }
    
    // 算术表达式
    virtual std::any visitAddExp(SysYParser::AddExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->mulExp(0)));
        
        for (size_t i = 1; i < ctx->mulExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->mulExp(i)));
            
            // 常数折叠
            if (result.isConst && rhs.isConst) {
                if (ctx->ADD(i-1)) {
                    result.constValue = result.constValue + rhs.constValue;
                } else {
                    result.constValue = result.constValue - rhs.constValue;
                }
                continue;
            }
            
            result = ensureInt32(result);
            rhs = ensureInt32(rhs);
            
            std::string tmp = genTmpVar();
            if (ctx->ADD(i-1)) {
                if (result.isConst) {
                    currentBB->addInstruction("%"+tmp+" = add i32 "+std::to_string(result.constValue)+", %"+rhs.name);
                } else if (rhs.isConst) {
                    currentBB->addInstruction("%"+tmp+" = add i32 %"+result.name+", "+std::to_string(rhs.constValue));
                } else {
                    currentBB->addInstruction("%"+tmp+" = add i32 %"+result.name+", %"+rhs.name);
                }
            } else {
                if (result.isConst) {
                    currentBB->addInstruction("%"+tmp+" = sub i32 "+std::to_string(result.constValue)+", %"+rhs.name);
                } else if (rhs.isConst) {
                    currentBB->addInstruction("%"+tmp+" = sub i32 %"+result.name+", "+std::to_string(rhs.constValue));
                } else {
                    currentBB->addInstruction("%"+tmp+" = sub i32 %"+result.name+", %"+rhs.name);
                }
            }
            result = IRValue(tmp, i32Type());
        }
        
        return result;
    }
    
    virtual std::any visitMulExp(SysYParser::MulExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->unaryExp(0)));
        
        for (size_t i = 1; i < ctx->unaryExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->unaryExp(i)));
            
            // 常数折叠
            if (result.isConst && rhs.isConst) {
                if (ctx->MUL(i-1)) {
                    result.constValue = result.constValue * rhs.constValue;
                } else if (ctx->DIV(i-1)) {
                    result.constValue = result.constValue / rhs.constValue;
                } else {
                    result.constValue = result.constValue % rhs.constValue;
                }
                continue;
            }
            
            result = ensureInt32(result);
            rhs = ensureInt32(rhs);
            
            std::string tmp = genTmpVar();
            if (ctx->MUL(i-1)) {
                if (result.isConst) {
                    currentBB->addInstruction("%"+tmp+" = mul i32 "+std::to_string(result.constValue)+", %"+rhs.name);
                } else if (rhs.isConst) {
                    currentBB->addInstruction("%"+tmp+" = mul i32 %"+result.name+", "+std::to_string(rhs.constValue));
                } else {
                    currentBB->addInstruction("%"+tmp+" = mul i32 %"+result.name+", %"+rhs.name);
                }
            } else if (ctx->DIV(i-1)) {
                if (result.isConst) {
                    currentBB->addInstruction("%"+tmp+" = sdiv i32 "+std::to_string(result.constValue)+", %"+rhs.name);
                } else if (rhs.isConst) {
                    currentBB->addInstruction("%"+tmp+" = sdiv i32 %"+result.name+", "+std::to_string(rhs.constValue));
                } else {
                    currentBB->addInstruction("%"+tmp+" = sdiv i32 %"+result.name+", %"+rhs.name);
                }
            } else {
                if (result.isConst) {
                    currentBB->addInstruction("%"+tmp+" = srem i32 "+std::to_string(result.constValue)+", %"+rhs.name);
                } else if (rhs.isConst) {
                    currentBB->addInstruction("%"+tmp+" = srem i32 %"+result.name+", "+std::to_string(rhs.constValue));
                } else {
                    currentBB->addInstruction("%"+tmp+" = srem i32 %"+result.name+", %"+rhs.name);
                }
            }
            result = IRValue(tmp, i32Type());
        }
        
        return result;
    }
    
    virtual std::any visitUnaryExp(SysYParser::UnaryExpContext *ctx) override {
        if (ctx->primaryExp()) {
            return visit(ctx->primaryExp());
        } else if (ctx->unaryOp() && ctx->unaryExp()) {
            IRValue val = getIRValue(visit(ctx->unaryExp()));
            
            std::string op = ctx->unaryOp()->getText();
            if (op == "+") {
                return val;
            } else if (op == "-") {
                // 如果是常数，直接返回负值
                if (val.isConst) {
                    IRValue result = val;
                    result.constValue = -val.constValue;
                    return result;
                }
                // 否则生成 sub 指令
                std::string tmp = genTmpVar();
                currentBB->addInstruction("%"+tmp+" = sub i32 0, %"+val.name);
                return IRValue(tmp, i32Type());
            } else if (op == "!") {
                // 如果是常数，直接计算
                if (val.isConst) {
                    IRValue result = IRValue("", i32Type());
                    result.isConst = true;
                    result.constValue = (val.constValue == 0) ? 1 : 0;
                    return result;
                }
                // 否则生成指令
                val = ensureInt32(val);
                std::string tmp = genTmpVar();
                currentBB->addInstruction("%"+tmp+" = icmp eq i32 %"+val.name+", 0");
                std::string tmp2 = genTmpVar();
                currentBB->addInstruction("%"+tmp2+" = zext i1 %"+tmp+" to i32");
                return IRValue(tmp2, i32Type());
            }
        } else if (ctx->IDENT()) {
            // 函数调用
            std::string funcName = ctx->IDENT()->getText();
            std::vector<IRValue> args;
            if (ctx->funcRParams()) {
                for (auto exp : ctx->funcRParams()->exp()) {
                    IRValue arg = getIRValue(visit(exp));
                    arg = ensureInt32(arg);
                    args.push_back(arg);
                }
            }
            
            std::string argStr;
            for (size_t i = 0; i < args.size(); ++i) {
                if (i > 0) argStr += ", ";
                if (args[i].isConst) {
                    argStr += "i32 " + std::to_string(args[i].constValue);
                } else {
                    argStr += "i32 %" + args[i].name;
                }
            }
            
            std::string tmp = genTmpVar();
            currentBB->addInstruction("%"+tmp+" = call i32 @"+funcName+"(" + argStr + ")");
            return IRValue(tmp, i32Type());
        }
        
        return IRValue("0", i32Type());
    }
    
    virtual std::any visitPrimaryExp(SysYParser::PrimaryExpContext *ctx) override {
        if (ctx->number()) {
            return visit(ctx->number());
        } else if (ctx->lVal()) {
            std::string name = ctx->lVal()->IDENT()->getText();
            Symbol *sym = symTable.lookup(name);
            
            if (!sym) {
                // 未定义的变量
                return IRValue("0", i32Type());
            }
            
            // 如果是常数，直接返回常数值
            if (sym->isConst) {
                IRValue val = IRValue("", i32Type());
                val.constValue = sym->constValue;
                val.isConst = true;
                return val;
            }
            
            // 从符号表获取 LLVM 名称并生成加载指令
            std::string tmp = genTmpVar();
            std::string llvmName = sym->llvmName;
            
            // llvmName 可能是 @name（全局）或 name（本地）
            if (llvmName[0] == '@') {
                // 全局变量
                currentBB->addInstruction("%"+tmp+" = load i32, i32* "+llvmName+", align 4");
            } else {
                // 本地变量
                currentBB->addInstruction("%"+tmp+" = load i32, i32* %"+llvmName+", align 4");
            }
            return IRValue(tmp, i32Type());
        } else if (ctx->exp()) {
            return visit(ctx->exp());
        }
        
        return IRValue("0", i32Type());
    }
    
    virtual std::any visitNumber(SysYParser::NumberContext *ctx) override {
        int value = std::stoi(ctx->getText());
        IRValue val = IRValue("", i32Type());
        val.isConst = true;
        val.constValue = value;
        return val;
    }
    
    // 比较表达式
    virtual std::any visitRelExp(SysYParser::RelExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->addExp(0)));
        
        for (size_t i = 1; i < ctx->addExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->addExp(i)));
            result = ensureInt32(result);
            rhs = ensureInt32(rhs);
            
            std::string tmp = genTmpVar();
            std::string cmp;
            if (ctx->LT(i-1)) cmp = "slt";
            else if (ctx->GT(i-1)) cmp = "sgt";
            else if (ctx->LE(i-1)) cmp = "sle";
            else if (ctx->GE(i-1)) cmp = "sge";
            
            if (result.isConst) {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" i32 "+std::to_string(result.constValue)+", %"+rhs.name);
            } else if (rhs.isConst) {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" i32 %"+result.name+", "+std::to_string(rhs.constValue));
            } else {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" i32 %"+result.name+", %"+rhs.name);
            }
            result = IRValue(tmp, i1Type());
        }
        
        return result;
    }
    
    virtual std::any visitEqExp(SysYParser::EqExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->relExp(0)));
        
        for (size_t i = 1; i < ctx->relExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->relExp(i)));
            
            std::string tmp = genTmpVar();
            std::string cmp = ctx->EQ(i-1) ? "eq" : "ne";
            
            // 根据操作数类型生成正确的 icmp 指令
            std::string opType = "i32";
            if (auto intType = std::dynamic_pointer_cast<IntegerType>(result.type)) {
                opType = intType->toString();
            }
            
            if (result.isConst) {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" "+opType+" "+std::to_string(result.constValue)+", %"+rhs.name);
            } else if (rhs.isConst) {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" "+opType+" %"+result.name+", "+std::to_string(rhs.constValue));
            } else {
                currentBB->addInstruction("%"+tmp+" = icmp "+cmp+" "+opType+" %"+result.name+", %"+rhs.name);
            }
            result = IRValue(tmp, i1Type());
        }
        
        return result;
    }
    
    virtual std::any visitLandExp(SysYParser::LandExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->eqExp(0)));
        
        for (size_t i = 1; i < ctx->eqExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->eqExp(i)));
            
            // AND 操作需要两个 bool 操作数，返回 bool
            // 如果操作数是 i32（来自非比较的 relExp），需要转换为 bool
            if (result.type && !std::dynamic_pointer_cast<IntegerType>(result.type)) {
                // 非整数类型，转换为 i1
                if (!result.isConst) {
                    std::string tmp = genTmpVar();
                    currentBB->addInstruction("%"+tmp+" = trunc i32 %"+result.name+" to i1");
                    result = IRValue(tmp, i1Type());
                } else {
                    result.type = i1Type();
                }
            }
            if (rhs.type && !std::dynamic_pointer_cast<IntegerType>(rhs.type)) {
                if (!rhs.isConst) {
                    std::string tmp = genTmpVar();
                    currentBB->addInstruction("%"+tmp+" = trunc i32 %"+rhs.name+" to i1");
                    rhs = IRValue(tmp, i1Type());
                } else {
                    rhs.type = i1Type();
                }
            }
            
            std::string tmp = genTmpVar();
            if (result.isConst && rhs.isConst) {
                result.constValue = result.constValue && rhs.constValue;
            } else if (result.isConst) {
                currentBB->addInstruction("%"+tmp+" = and i1 i1 "+std::to_string(result.constValue)+", %"+rhs.name);
                result = IRValue(tmp, i1Type());
            } else if (rhs.isConst) {
                currentBB->addInstruction("%"+tmp+" = and i1 %"+result.name+", i1 "+std::to_string(rhs.constValue));
                result = IRValue(tmp, i1Type());
            } else {
                currentBB->addInstruction("%"+tmp+" = and i1 %"+result.name+", %"+rhs.name);
                result = IRValue(tmp, i1Type());
            }
        }
        
        return result;
    }
    
    virtual std::any visitLorExp(SysYParser::LorExpContext *ctx) override {
        IRValue result = getIRValue(visit(ctx->landExp(0)));
        
        for (size_t i = 1; i < ctx->landExp().size(); ++i) {
            IRValue rhs = getIRValue(visit(ctx->landExp(i)));
            
            // OR 操作需要两个 bool 操作数，返回 bool
            if (result.type && !std::dynamic_pointer_cast<IntegerType>(result.type)) {
                if (!result.isConst) {
                    std::string tmp = genTmpVar();
                    currentBB->addInstruction("%"+tmp+" = trunc i32 %"+result.name+" to i1");
                    result = IRValue(tmp, i1Type());
                } else {
                    result.type = i1Type();
                }
            }
            if (rhs.type && !std::dynamic_pointer_cast<IntegerType>(rhs.type)) {
                if (!rhs.isConst) {
                    std::string tmp = genTmpVar();
                    currentBB->addInstruction("%"+tmp+" = trunc i32 %"+rhs.name+" to i1");
                    rhs = IRValue(tmp, i1Type());
                } else {
                    rhs.type = i1Type();
                }
            }
            
            std::string tmp = genTmpVar();
            if (result.isConst && rhs.isConst) {
                result.constValue = result.constValue || rhs.constValue;
            } else if (result.isConst) {
                currentBB->addInstruction("%"+tmp+" = or i1 i1 "+std::to_string(result.constValue)+", %"+rhs.name);
                result = IRValue(tmp, i1Type());
            } else if (rhs.isConst) {
                currentBB->addInstruction("%"+tmp+" = or i1 %"+result.name+", i1 "+std::to_string(rhs.constValue));
                result = IRValue(tmp, i1Type());
            } else {
                currentBB->addInstruction("%"+tmp+" = or i1 %"+result.name+", %"+rhs.name);
                result = IRValue(tmp, i1Type());
            }
        }
        
        return result;
    }
    
    // 常量计算
    virtual std::any visitInitVal(SysYParser::InitValContext *ctx) override {
        if (ctx->exp()) {
            return visit(ctx->exp());
        }
        return IRValue("0", i32Type());
    }
    
    int evalConstInitVal(SysYParser::ConstInitValContext *ctx) {
        if (!ctx) return 0;
        if (ctx->constExp()) {
            return evalConstExp(ctx->constExp());
        }
        return 0;
    }
    
    int evalConstInitVal(SysYParser::InitValContext *ctx) {
        if (!ctx) return 0;
        if (ctx->exp()) return evalConstExp(ctx->exp()->addExp());
        return 0;
    }
    
    int evalConstExp(SysYParser::ConstExpContext *ctx) {
        return evalAddExp(ctx->addExp());
    }
    
    int evalConstExp(SysYParser::AddExpContext *ctx) {
        return evalAddExp(ctx);
    }
    
    int evalAddExp(SysYParser::AddExpContext *ctx) {
        int val = evalMulExp(ctx->mulExp(0));
        for (size_t i = 1; i < ctx->mulExp().size(); ++i) {
            int rhs = evalMulExp(ctx->mulExp(i));
            if (ctx->ADD(i-1)) val += rhs;
            else val -= rhs;
        }
        return val;
    }
    
    int evalMulExp(SysYParser::MulExpContext *ctx) {
        int val = evalUnaryExp(ctx->unaryExp(0));
        for (size_t i = 1; i < ctx->unaryExp().size(); ++i) {
            int rhs = evalUnaryExp(ctx->unaryExp(i));
            if (ctx->MUL(i-1)) val *= rhs;
            else if (ctx->DIV(i-1)) val /= rhs;
            else val %= rhs;
        }
        return val;
    }
    
    int evalUnaryExp(SysYParser::UnaryExpContext *ctx) {
        if (ctx->primaryExp()) {
            return evalPrimaryExp(ctx->primaryExp());
        } else if (ctx->unaryOp() && ctx->unaryExp()) {
            int val = evalUnaryExp(ctx->unaryExp());
            std::string op = ctx->unaryOp()->getText();
            if (op == "-") return -val;
            if (op == "!") return (val == 0) ? 1 : 0;
            return val;
        }
        return 0;
    }
    
    int evalPrimaryExp(SysYParser::PrimaryExpContext *ctx) {
        if (ctx->number()) {
            return std::stoi(ctx->number()->getText());
        }
        return 0;
    }
};
